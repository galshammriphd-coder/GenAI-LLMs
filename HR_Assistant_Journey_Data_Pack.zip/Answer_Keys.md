# HR Assistant Journey — Answer Keys (trainer only)

All data are synthetic. Northwind Gulf Bank is fictional.

## Station 1 · Choose Your Assistant
- **T1:** Customer Service turnover 2025 = 38 ÷ ((180 + 190) ÷ 2) = 38 ÷ 185 = **20.5%**, up **+6.5 percentage points** from 14.0%. Common errors: 38 ÷ 190 = 20.0%; "+6.5%".
- **T2:** Workload & shifts 5 (C1, C2, C6, C9, C11) · Career growth 3 (C3, C7, C10) · Training access 2 (C4, C5) · Recognition 2 (C8, C12). Most urgent: **C4** (AML missed: compliance risk). Customer Service wrote 6 of 12.
- **T3:** Arabic ad passes four checks: clear MSA, no age/gender/nationality limits, essential vs desirable, nothing invented.
- **Tokens (H3, legacy tokenizer):** EN 157 vs AR 506 (3.2×); EN 112 words vs AR 98 words.
- **Fit test:** 150 pages × 300 words = 45,000 words → legacy ≈ 232K tokens (does not fit 123K); modern ≈ 90K (fits).
- **Results slide scores are illustrative.**

## Station 2 · Trust but Verify — the 8 errors
1. Headcount +10% → **+5.3%** (570 → 600) — calculation
2. Turnover "fell to 10.5%" → **rose 10.5% → 12.3%** (72 ÷ 585) — direction
3. CS "+6.5%" → **+6.5 pp** — unit
4. IT "increased" → **fell 10.0% → 9.5%** — direction
5. Training rose "across all" → **fell in Ops (26→24) and CS (22→18)**; bank 27.0 → 26.4 — overgeneralising
6. AML 100% everywhere → **only Finance 100%; CS 86%**; bank 95.1% → 93.4% — fabrication
7. Engagement "improved thanks to hybrid work" → **fell 3.69 → 3.57**; cause unsupported
8. "Highest in the banking sector" → **no benchmark** — unsupported claim
Bonus: "excellent year" (tone) · "no further action" (contradicts data).

## Station 3 · From Numbers to a Story
- Lenses: level 20.5% · change +6.5 pp · drivers (engagement 3.5→3.1, training 22→18 h, AML 92%→86%, 5 workload comments) · implication (service + AML risk).
- Observed: statements 1–3. Hypothesis: 4 (test with exit interviews), 5 (no data — drop).
- CS = 190/600 = 32% of staff, 38/72 = 53% of leavers.
- Actions: Head of CS — two-week shift notice (Q1) · L&D — AML catch-up off-peak (30 days) · HR — exit interviews (Q1).

## Station 4 · Build the HR Assistant
- Leave: 14 unused days → carry over **10**, use by **31 March**, **4 forfeited** (Policy §2).
- Correction: Ops leavers 21 → 21 ÷ 153 = **13.7%** (+4.2 pp vs 9.5%); bank 78 ÷ 585 = **13.3%**. Assistant must state the override.
- Test 7 must decline (privacy + human decision).

## Capstone
Rubric 25/20/15/15/10/10/5. Gate: one invented figure caps Accuracy at 10/25. Bands: 85+ Exemplary · 70–84 Proficient · 55–69 Developing · <55 Not yet competent.
