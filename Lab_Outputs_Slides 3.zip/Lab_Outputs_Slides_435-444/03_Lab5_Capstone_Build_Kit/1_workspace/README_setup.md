# Setting up the workspace (CP1–CP2)

## Claude (primary)
1. Create a Project named **NGB Finance Reporting Assistant (Training)**.
2. Paste `workspace_instructions.md` into the Project instructions.
3. Upload `2_knowledge_files/DS-1.md`, `DS-2.md`, `DS-3.md` (DS-4, DS-5 optional) and `4_templates/templates.md`.
4. Upload the five skills from `3_skills/zips/` (one ZIP per skill) in Settings → Capabilities → Skills, and enable them.

## Gemini Gem or ChatGPT Project (fallback)
1. Paste `workspace_instructions.md` as the Gem / Project instructions (keep the routing guide at the top).
2. Upload the knowledge files, `templates.md` and `3_skills/skills-handbook.md` (all five skills in one file).

## Checks
- CP1: workspace exists with instructions and three knowledge files.
- CP2: five skills available (or the handbook uploaded) and the routing guide present.
