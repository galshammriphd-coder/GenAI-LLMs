# Glossary AR–EN
| العربية | English |
|---|---|
| صافي الدخل | Net income |
| إجمالي دخل العمليات | Total operating income |
| نسبة التكلفة إلى الدخل | Cost-to-income ratio |
| مخصصات الانخفاض في القيمة | Impairment charges |
| نسبة القروض المتعثرة | NPL ratio |
| نسبة تغطية القروض المتعثرة | NPL coverage ratio |
| نسبة القروض إلى الودائع | Loan-to-deposit ratio |
| نسبة الشريحة الأولى من رأس المال العام | CET1 ratio |
| العائد على حقوق الملكية | Return on equity (ROE) |
| نقطة مئوية | Percentage point (pp) |
