---
name: financial-statement-summarizer
description: Summarizes income statements and balance sheets into a concise key-metrics table and plain-language summary for a chosen audience, and returns the key numbers as JSON on request. Use when the user asks to summarize financial statements, give the key numbers, provide a quick overview of results, or output figures as JSON.
---

# Financial Statement Summarizer
Version: 1.1 · Owner: [team] · Synthetic training use

## Inputs
Required: statement(s) with period labels and unit. Optional: audience (default ExCo), language (default English), word limit (default 200), format (default text; JSON on request).

## Steps
1. Identify statement type(s) and periods.
2. Extract 6–10 headline metrics.
3. Compute changes (pp for ratios).
4. Write a 5-bullet summary for the audience (plain language if the audience is customers or non-financial Board members).
5. List watch points and data gaps.

## Output
Key metrics table → 5 bullets → Watch points → Data gaps → Sources.

## JSON mode
When the user asks for JSON: output JSON only — no commentary, no code fences unless asked — conforming to references/summary-schema.json. Use numbers, not strings; ratios as decimals (0.373); amounts in SAR millions.

## Rules
Only provided data; no adjectives without figures; if no statement is detected, explain and stop. Arabic terms: references/glossary-ar-en.md.
