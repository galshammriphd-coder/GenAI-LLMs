# Changelog — business-correspondence
- 1.1 · Added data-correction handling and source line; sharpened description (Lab 5 test fixes)
- 1.0 · First version (LAB-4)
