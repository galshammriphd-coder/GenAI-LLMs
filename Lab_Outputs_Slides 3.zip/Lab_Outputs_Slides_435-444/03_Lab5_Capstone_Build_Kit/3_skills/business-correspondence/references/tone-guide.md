# Tone guide
- Courteous, clear, no blame ("you should have…" is not allowed).
- No promises of outcome ("we will refund") unless the user confirmed them.
- Plain language; one idea per sentence; active voice.
- Formal Arabic (MSA) when Arabic is requested — written natively, not translated word for word.
