# Letter structures
| Recipient · channel | Structure |
|---|---|
| Customer · letter / email | Subject · greeting · purpose · facts · decision or next step · options · contact · closing |
| Customer · SMS | Purpose · reference · next step · channel (≤ 2 segments) |
| Partner · email | Subject · purpose · context · request · deadline · closing |
| Internal · memo | To/From/Date · purpose · background · proposal · decision needed |

## Declining a request (e.g., fee waiver)
Thank → state the decision clearly and once → give the reason (policy, not blame) → offer an alternative if one exists → contact → closing.
