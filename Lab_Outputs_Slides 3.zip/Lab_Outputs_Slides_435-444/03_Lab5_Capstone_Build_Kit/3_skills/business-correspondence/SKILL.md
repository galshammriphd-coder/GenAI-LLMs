---
name: business-correspondence
description: Drafts formal business correspondence for a bank — customer letters, complaint responses, partner emails and internal memos — in English or formal Arabic, following tone and compliance-safe wording rules. Use when the user asks to write, reply to or improve a letter, email, memo or customer message.
---

# Business Correspondence
Version: 1.1 · Owner: [team] · Synthetic training use

## Inputs
Purpose, recipient type (customer / partner / internal), key facts, desired action, language, channel (letter / email / SMS). If key facts are missing, ask for them before drafting.

## Steps
1. Select the structure from references/letter-structures.md by recipient and channel.
2. Draft: subject, greeting, purpose in the first sentence, facts, next steps with timing, closing.
3. Apply references/tone-guide.md: courteous, clear, no blame, no promises of outcomes not confirmed by the user.
4. For SMS: ≤ 160 characters per segment for Latin text; Arabic (Unicode) SMS allows 70 characters in a single segment (67 per segment when concatenated) — keep within 2 segments; include a reference number.

## Output
Draft + a short "Check before sending" list (facts to verify, attachments, approvals).

## Rules
Never include account numbers or personal data beyond what the user provides; never invent fees, rates or dates — use placeholders such as [X business days].
