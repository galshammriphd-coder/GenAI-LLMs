# Briefing template
**Headline:** [result + concern, ≤ 15 words]
**Situation:** [1–2 sentences with figures]
**Complication:** [1–2 sentences with figures]
**Question:** [the decision question]
**Answer:** [2–3 actions with owners]
| Action | Owner | Timing | Finding addressed |
|---|---|---|---|
**Decision requested:** [one sentence]
Sources: [DS-x]
