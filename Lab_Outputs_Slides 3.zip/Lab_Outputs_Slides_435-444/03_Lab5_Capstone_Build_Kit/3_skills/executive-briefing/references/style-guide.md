# Style guide
- Neutral tone; no promotional adjectives ("outstanding", "strong") without a figure.
- One number per sentence where possible; pp for ratio changes; % for amounts.
- Answer first: the headline states the result and the main concern.
- Roles, not names, as owners (CRO, Treasurer, Head of Retail).
- Cite sources in brackets: (DS-1).
