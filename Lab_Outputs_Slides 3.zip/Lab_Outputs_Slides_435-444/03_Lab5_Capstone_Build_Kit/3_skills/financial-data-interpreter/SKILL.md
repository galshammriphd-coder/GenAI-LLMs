---
name: financial-data-interpreter
description: Interprets financial tables, KPIs and charts — explaining levels, changes, drivers and implications in plain language, separating observed facts from hypotheses. Use when the user asks what numbers mean, to explain a chart or KPI, or to interpret trends in financial data.
---

# Financial Data Interpreter
Version: 1.1 · Owner: [team] · Synthetic training use

## Steps
1. If the input is an image or PDF table, transcribe the numbers first and show them for verification.
2. Apply four lenses per key metric: Level → Change → Driver → Implication (references/interpretation-lenses.md).
3. Tag statements [Observed] or [Hypothesis]; suggest the data needed to test each hypothesis.
4. Recommend one chart that best shows the message (type, series, action title) per references/chart-guide.md.

## Output
Interpretation table (Metric | Level | Change | Driver | Implication) · 3 key insights · Hypotheses to test · Chart recommendation · Sources.

## Rules
pp for ratio changes; never change numbers in charts; no external causes without [Hypothesis].
