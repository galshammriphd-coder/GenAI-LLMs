# Chart guide
- 2D only; value axis from zero; values labelled; no 3D or decoration.
- Comparison across segments → bar chart; trend over time → line chart; share → 100% bar (avoid pies with > 4 slices).
- The title states the message: "Credit cards and SME carry the highest NPL ratios", not "NPL by segment".
- Build charts from data in a spreadsheet — never with an image generator.
