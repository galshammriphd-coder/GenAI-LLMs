# Four lenses
| Lens | Question | Example (ROE) |
|---|---|---|
| Level | What is the value? | 13.0% |
| Change | Versus prior period or budget | 13.1% → 13.0% (−0.1 pp) |
| Driver | What explains the change? | Impairments +20.5% (DS-1) |
| Implication | So what for decisions? | Review SME underwriting |

## NPL coverage example
Level 152% · Change −16 pp from 168% · Driver: NPLs grew faster than provisions (NPL ratio 1.6% → 1.9%) [Observed for the ratio; the provisions split is not provided] · Implication: provisions still exceed NPLs, but the buffer is thinner — monitor as SME and card NPLs rise.
