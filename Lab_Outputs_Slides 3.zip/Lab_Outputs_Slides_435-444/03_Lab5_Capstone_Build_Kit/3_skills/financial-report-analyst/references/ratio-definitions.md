# Ratio definitions
| Ratio | Formula | Note |
|---|---|---|
| Cost-to-income | Operating expenses ÷ Total operating income | DS-1 |
| Loan-to-deposit | Net loans ÷ Customer deposits | DS-2 |
| NPL ratio | Non-performing loans ÷ Gross loans | Use the reported value if given (DS-2, DS-3) |
| NPL coverage | Loan-loss provisions ÷ Non-performing loans | Use the reported value (DS-2) |
| ROE | Net income ÷ Average total equity | FY2025: 2,889 ÷ 22,250 = 13.0% |
| ROA | Net income ÷ Average total assets | FY2025: 2,889 ÷ 257,250 = 1.12% |
| Δ% | (Current − Prior) ÷ Prior × 100 | Amounts only |
| Δ pp | Current ratio − Prior ratio | Ratios only |
