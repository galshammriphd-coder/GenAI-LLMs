# Example — good analysis (abridged)
**Headline:** Net income +6.4% as income outgrew costs; impairments +20.5% are the watch point
| Metric | FY2024 | FY2025 | Δ | Δ% / pp |
|---|---|---|---|---|
| Net income (SAR m) | 2,714 | 2,889 | +175 | +6.4% |
| Cost-to-income | 38.1% | 37.3% | — | −0.8 pp |
| Impairment charges (SAR m) | 610 | 735 | +125 | +20.5% |
Drivers: [Observed] net interest income +335; [Observed] impairments −125; [Observed] operating expenses −115. Sources: DS-1.
