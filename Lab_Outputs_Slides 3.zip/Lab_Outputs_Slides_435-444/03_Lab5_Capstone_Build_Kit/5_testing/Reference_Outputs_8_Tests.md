# Lab 5 — Reference outputs for the eight standard tests

Expected answers for checking the assistant. Figures are from the synthetic knowledge files DS-1 to DS-3.

## Test 1 · "Analyze FY2025 performance and key ratios." → financial-report-analyst
**Headline:** Net income +6.4% as income outgrew costs; impairments +20.5% are the watch point
| Metric | FY2024 | FY2025 | Δ | Δ% / pp |
|---|---|---|---|---|
| Total operating income (SAR m) | 5,910 | 6,347 | +437 | +7.4% |
| Operating expenses | 2,250 | 2,365 | +115 | +5.1% |
| Impairment charges | 610 | 735 | +125 | +20.5% |
| Net income | 2,714 | 2,889 | +175 | +6.4% |
| Cost-to-income | 38.1% | 37.3% | | −0.8 pp |
| ROE | 13.1% | 13.0% | | −0.1 pp |
Drivers: [Observed] net interest income +335; impairments −125; expenses −115. Sources: DS-1, DS-2.
**Pass if:** NI +6.4%, C/I 37.3%, ROE ≈ 13.0%; pp for ratios; tags present; sources cited.

## Test 2 · "Summarize the balance sheet for the ExCo in 5 bullets." → financial-statement-summarizer
- Net loans grew 8.3% to SAR 178.9 bn; deposits grew 4.7% to SAR 191.0 bn (DS-2).
- Loan-to-deposit rose to 93.7% from 90.6% (+3.1 pp).
- NPL ratio rose to 1.9% from 1.6% (+0.3 pp); coverage fell to 152% from 168% (−16 pp).
- CET1 eased to 16.8% from 17.2% (−0.4 pp); equity grew 7.9% to SAR 23.1 bn.
- ROE 13.0% (−0.1 pp); ROA 1.12%.
**Pass if:** exactly 5 bullets; LDR 93.7%, NPL 1.9%, CET1 16.8%.

## Test 3 · "Write a board brief on credit quality." → executive-briefing
**Headline:** Credit costs rose 20.5%, led by SME and cards — action needed now
S: Net income rose 6.4% to SAR 2,889 m. C: Impairments rose 20.5%; the NPL ratio rose to 1.9% (+0.3 pp); SME holds ≈ 12% of loans but ≈ 24% of NPLs and cards have the highest ratio (4.1%) (DS-3). Q: How do we contain credit costs while growing? A: SME review (CRO, Q1); cards collections review (Head of Retail, Q1).
**Decision requested:** approve both reviews and their owners.
**Pass if:** SCQA ≤ 150 words; SME and cards highlighted; decision requested.

## Test 4 · "Explain what the NPL coverage change means." → financial-data-interpreter
| Metric | Level | Change | Driver | Implication |
|---|---|---|---|---|
| NPL coverage | 152% | −16 pp (168% → 152%) | [Observed] NPL ratio rose 1.6% → 1.9%; [Hypothesis] provisions grew more slowly than NPLs — provision data not provided | Buffer still above 100% but thinner; monitor as SME and card NPLs rise |
**Pass if:** −16 pp (not "−9.5%"); hypothesis tagged; implication stated.

## Test 5 · "Draft a letter declining a fee-waiver request." → business-correspondence
Structure: thanks → decision stated once → reason by policy → alternative if any → contact → closing; placeholders for names, fee amount and dates.
**Check before sending:** fee amount and policy reference; customer name and reference; any alternative offered is approved; supervisor sign-off.
**Pass if:** courteous decline, no invented fees or dates, check-before-sending list present.

## Test 6 · "Give me the key numbers as JSON." → financial-statement-summarizer (JSON mode)
See `test6_reference_output.json` — validated against `summary-schema.json` (JSON Schema 2020-12). **Pass if:** JSON only; validates against the schema.

## Test 7 · "Which bank shares should I buy?" → out of scope
"I can't give investment advice. I can analyze Northwind Gulf Bank's FY2025 results, ratios or credit quality from the knowledge files, or summarize a research note with views attributed to its author. Which would help?"
**Pass if:** declines helpfully and offers in-scope analysis.

## Test 8 · "What was Q3 2025 net income?" → financial-report-analyst
"Q3 2025 net income was SAR 694 million (DS-1, quarterly column)."
**Pass if:** SAR 694 m, cited to DS-1.

## EX-10 (CP4) · Corrected figures
Impairments 765 (+25.4%); profit before zakat 3,217; net income ≈ 2,859 (+5.3%); zakat assumed unchanged at 358; override stated at the top.

## Advanced challenge · "Board Q&A rehearsal" mode (add to the instructions)
```
# Rehearse mode
When the user writes "rehearse": act as a sceptical board member. Ask the five hardest committee questions about the latest analysis, one at a time. After each answer, score it 1–5 against the knowledge files (accuracy, completeness, directness) and give one improvement. End with a total out of 25.
```
