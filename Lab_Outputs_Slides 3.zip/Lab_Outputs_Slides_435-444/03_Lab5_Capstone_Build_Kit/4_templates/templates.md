# templates.md — NGB Finance Reporting Assistant (Training)
Upload as a knowledge file. Fill the {{variables}}; the template asks for any missing required variable.

---
## RP-T01 · Variance Commentary · v1.0
[Validate] Required: {{period}}, {{comparison_period}}, {{audience}}, {{data}}. If missing, ask and stop.
[Role] You are a financial analyst writing for {{audience}}.
[Task] Explain the changes between {{comparison_period}} and {{period}}.
[Steps] 1) Compute Δ and Δ% per line (pp for ratios). 2) Rank the top {{n_drivers | default: 3}} drivers of net income change. 3) Write commentary.
[Rules] Use only <data>. Tag statements [Observed]/[Hypothesis]. No promotional adjectives. If audience = Board, max {{word_limit | default: 150}} words; else 250.
[Format] Table (Line | {{comparison_period}} | {{period}} | Δ | Δ%) → "Drivers" → "Commentary" → "Open questions".
<data>{{data}}</data>
Usage note: income statement in SAR m; annual or quarterly data; not for segment data.

---
## RD-T01 · Research Digest · v1.0
[Validate] Required: {{note}}. If missing, ask and stop.
[Task] Using only <note>, produce: Thesis · Key figures · Catalysts · Risks · Rating & target · What's new · Questions for the analyst.
[Rules] Attribute every view to the author ("The author expects…"); never add your own recommendation. End with: "This digest summarizes third-party research and is not investment advice."
<note>{{note}}</note>
Usage note: broker notes and earnings-call transcripts; not for internal forecasts.

---
## IC-T01 · Insurance Coverage Check · v1.0
[Validate] Required: {{policy}}, {{claim}}. If missing, ask and stop.
[Task] Using only <policy> and <claim>, list: (1) relevant clauses (quote + clause number); (2) whether each claim item appears Covered, Excluded or Unclear; (3) missing documents.
[Rules] Do not decide the claim. Mark the output "Draft for adjuster review".
[Format] Table: Claim item | Clause (quote) | Status | Reason → Missing documents → Overall status.
<policy>{{policy}}</policy> <claim>{{claim}}</claim>

---
## CS-T01 · Complaint-Theme FAQs and Reply · v1.0
[Validate] Required: {{complaints}}, {{complaint_id}}. If missing, ask and stop.
[Task] Identify the top theme with its count. Write 5 FAQs (question ≤ 15 words; answer ≤ 60 words, plain language, no promises). Draft one email reply to {{complaint_id}} with a reference number and next steps.
[Rules] No promise of outcome; placeholders for timelines ([X business days]); add a "Check before sending" list.
<complaints>{{complaints}}</complaints>
