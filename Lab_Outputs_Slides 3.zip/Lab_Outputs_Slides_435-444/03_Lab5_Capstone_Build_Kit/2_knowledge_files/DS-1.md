# DS-1 · Northwind Gulf Bank (fictional) — Income Statement FY2025 with FY2024 comparative
Version 1.0 · synthetic training data · SAR millions

| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |

