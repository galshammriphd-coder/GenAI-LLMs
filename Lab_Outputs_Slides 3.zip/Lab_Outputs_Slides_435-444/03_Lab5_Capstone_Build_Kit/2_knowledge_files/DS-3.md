# DS-3 · Northwind Gulf Bank (fictional) — Loan Portfolio by Segment
Version 1.0 · synthetic training data

| Segment | Loans 31 Dec 2024 (SAR bn) | Loans 31 Dec 2025 (SAR bn) | Growth | NPL ratio 2025 |
|---|---|---|---|---|
| Retail mortgages | 48.1 | 52.4 | +8.9% | 0.9% |
| Personal finance | 37.0 | 38.6 | +4.3% | 1.7% |
| Credit cards | 5.9 | 6.2 | +5.1% | 4.1% |
| SME | 18.2 | 21.3 | +17.0% | 3.8% |
| Corporate | 56.0 | 60.4 | +7.9% | 2.0% |
| Total | 165.2 | 178.9 | +8.3% | 1.9% |
