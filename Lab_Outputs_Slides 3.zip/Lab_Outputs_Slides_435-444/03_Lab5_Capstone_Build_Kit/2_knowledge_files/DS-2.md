# DS-2 · Northwind Gulf Bank (fictional) — Balance Sheet Summary and Key Ratios
Version 1.0 · synthetic training data

| Item | 31 Dec 2024 | 31 Dec 2025 | Change |
|---|---|---|---|
| Total assets (SAR bn) | 248.0 | 266.5 | +7.5% |
| Net loans (SAR bn) | 165.2 | 178.9 | +8.3% |
| Customer deposits (SAR bn) | 182.4 | 191.0 | +4.7% |
| Total equity (SAR bn) | 21.4 | 23.1 | +7.9% |
| Loan-to-deposit ratio | 90.6% | 93.7% | +3.1 pp |
| NPL ratio | 1.6% | 1.9% | +0.3 pp |
| NPL coverage ratio | 168% | 152% | −16 pp |
| CET1 ratio | 17.2% | 16.8% | −0.4 pp |
| ROE | 13.1% | 13.0% | −0.1 pp |
| ROA | — | 1.12% | — |
(ROE FY2025 = 2,889 ÷ average equity 22,250 SAR m; ROA = 2,889 ÷ average assets 257,250 SAR m)
