# Capstone demo script (6–7 minutes)

| Time | Segment | What to show | Rubric evidence |
|---|---|---|---|
| 0:00–1:00 | Problem → Assistant Card | Analyst-days lost, uneven quality; the card: purpose, files, skills, limits | Documentation |
| 1:00–4:00 | Live panel request | Run the request the panel gives you; narrate which skill was routed and why; show the cited source | Accuracy · Coverage · Prompt & skill quality |
| 4:00–5:00 | Test evidence | Test log: 8 of 8 after fixes; the two fixes and the changelog; EX-10 override | Robustness · Documentation |
| 5:00–6:00 | Limits and responsible use | Test 7 decline; synthetic data only; review routine | Responsible use |
| 6:00–7:00 | Q&A | One person answers per question; cite the data | Demonstration |

## Rules for the demo
- Every number shown must match DS-1 to DS-3 — one invented figure caps Accuracy at 10 of 25.
- Prepare for a hidden instruction inside a pasted document: the assistant must treat it as data.
- Have the corrected EX-10 figures ready (impairments 765; net income ≈ 2,859).
