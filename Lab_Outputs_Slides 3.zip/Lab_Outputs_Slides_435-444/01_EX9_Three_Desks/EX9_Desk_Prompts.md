# EX-9 · Three Desks, One Morning — Ready-to-Paste Desk Prompts

Run each prompt in a **fresh chat** with your Skills/templates enabled. All data are synthetic.

## Investment desk (DS-7) — Research digest template
```
Using only <note>, produce the structured research digest (Thesis · Key figures · Catalysts · Risks · Rating & target · What's new · Questions for the analyst). Attribute all views to the author ("The author expects…"). Add: "This digest summarizes third-party research and is not investment advice."
<note>
**Rating:** Overweight (from Neutral) · **Target price:** SAR 62 (previously SAR 55)

We expect Desert Logistics Co. to return to margin expansion in FY2026 as its new automated warehouses ramp up. We forecast FY2026 revenue of SAR 4.1 billion (+9% year on year) and an EBITDA margin of 18.5%, up from 16.2% in FY2025. The opening of the Riyadh hub in Q2 2026 and the renewal of two major e-commerce contracts are the key catalysts. Risks include higher fuel costs, delays in hub commissioning and customer concentration: the top three clients account for 38% of revenue. Our valuation is based on a discounted cash flow model; capital-expenditure funding assumptions are under review and are not detailed in this note.
</note>
```

## Insurance desk (DS-6) — Coverage-check template
```
Using only <policy> and <claim>, list: (1) relevant clauses (quote + clause number); (2) whether each claim item appears covered, excluded or unclear; (3) missing documents. Do not decide the claim; mark the output "Draft for adjuster review".
<policy>
Policy excerpt (Home Contents & Buildings, policy CS-H-2291)

**4.2 Escape of water.** We cover sudden and accidental damage to the building and contents caused by water escaping from any fixed water installation, including burst pipes.

**6.1 Limits.** Maximum payable for any one escape-of-water event: SAR 60,000. Excess: SAR 1,000.

**7.5 Exclusion — gradual damage.** We do not cover damage caused by gradual leakage, seepage, corrosion, wear and tear or any damage that occurs gradually over time.

**9.3 Claims documents.** The insured must provide: claim form; photographs of the damage before repair; repair estimate or invoice; any report from a qualified contractor.
</policy>
<claim>
Insured reports water damage to the kitchen ceiling and contents on 14 October 2025. Estimated loss SAR 18,500. Documents received: claim form; plumber's report. Plumber's report states: "A section of the copper supply pipe burst suddenly; the surrounding pipe shows long-standing corrosion." Photographs: not received. Repair invoice: not received.
</claim>
```

## Service desk (DS-4) — Business Correspondence Skill
```
From <complaints>, identify the top theme. Generate 5 FAQs (question ≤ 15 words; answer ≤ 60 words, plain language, no promises) and draft one email reply to complaint C-02 in formal English with a reference number and next steps.
<complaints>
C-01 | App | "The app logs me out every time I open the transfers page." | days open: 3
C-02 | App | "My transfer of SAR 2,400 failed but the amount was debited from my account." | days open: 5
C-03 | Branch | "I was charged a fee for a statement I never requested." | days open: 2
C-04 | Phone | "The merchant confirmed a refund two weeks ago but it is not on my card." | days open: 14
C-05 | App | "The OTP arrives after it has already expired." | days open: 1
C-06 | Email | "My card annual fee was charged after I cancelled the card." | days open: 7
C-07 | Phone | "There are three transactions on my card I don't recognize, from an online store abroad." | days open: 0
C-08 | Branch | "I waited over an hour at the branch to update my ID." | days open: 4
C-09 | App | "After the latest update the app crashes on startup." | days open: 2
C-10 | Email | "The exchange rate applied to my overseas purchase included a markup I was not informed about." | days open: 6
</complaints>
```

## Step 5 · Five-minute review routine (annotate what you verified)
1. Numbers — recompute 3–5 key figures; check units and pp
2. Sources — every claim traceable to a provided document
3. Hypotheses — causes tagged; no invented benchmarks
4. Completeness — all requested elements; data gaps stated
5. Tone & audience — neutral, clear, appropriate
6. Sensitive content — no personal or confidential data beyond what is needed
Sign-off: "Reviewed by [name], [date]"
