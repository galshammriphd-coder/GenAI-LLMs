# EX-10 · Prompt with an explicit data override

```
DATA CORRECTION (overrides the knowledge file DS-1):
Finance has confirmed that Q4 2025 impairment charges were understated.
Use SAR 265 million for Q4 2025 impairments, not SAR 235 million as in DS-1.
Keep every other DS-1 figure unchanged. Assume FY2025 zakat stays at SAR 358 million and state this assumption.

TASK (for the CFO, who meets the Chairman in 15 minutes):
1. Recalculate the corrected FY2025 key figures: impairment charges, profit before zakat, net income — each with the change vs FY2024. Show the formula once.
2. Write a three-line message for the Chairman (one figure per line).
3. Write one sentence on what changed and why it matters.
4. List what you could not verify.

Use the Executive Briefing Skill. State at the top: "Override applied: Q4 impairments SAR 265 m (user correction) replaces DS-1."
```

Workspace rule that makes this automatic (add to the instructions):
> If the user provides corrected figures, use them over the knowledge files and state the override at the top of the answer.
