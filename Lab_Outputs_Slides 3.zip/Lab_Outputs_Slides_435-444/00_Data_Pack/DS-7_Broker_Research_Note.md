# DS-7 · Broker Research Note — Desert Logistics Co. (synthetic)

**Rating:** Overweight (from Neutral) · **Target price:** SAR 62 (previously SAR 55)

We expect Desert Logistics Co. to return to margin expansion in FY2026 as its new automated warehouses ramp up. We forecast FY2026 revenue of SAR 4.1 billion (+9% year on year) and an EBITDA margin of 18.5%, up from 16.2% in FY2025. The opening of the Riyadh hub in Q2 2026 and the renewal of two major e-commerce contracts are the key catalysts. Risks include higher fuel costs, delays in hub commissioning and customer concentration: the top three clients account for 38% of revenue. Our valuation is based on a discounted cash flow model; capital-expenditure funding assumptions are under review and are not detailed in this note.
