# DS-6 · Crescent Shield Insurance — Home Policy Excerpt and Claim (synthetic)

## Policy excerpt (Home Contents & Buildings, policy CS-H-2291)

**4.2 Escape of water.** We cover sudden and accidental damage to the building and contents caused by water escaping from any fixed water installation, including burst pipes.

**6.1 Limits.** Maximum payable for any one escape-of-water event: SAR 60,000. Excess: SAR 1,000.

**7.5 Exclusion — gradual damage.** We do not cover damage caused by gradual leakage, seepage, corrosion, wear and tear or any damage that occurs gradually over time.

**9.3 Claims documents.** The insured must provide: claim form; photographs of the damage before repair; repair estimate or invoice; any report from a qualified contractor.

## Claim summary (claim CL-7781)

Insured reports water damage to the kitchen ceiling and contents on 14 October 2025. Estimated loss SAR 18,500. Documents received: claim form; plumber's report. Plumber's report states: "A section of the copper supply pipe burst suddenly; the surrounding pipe shows long-standing corrosion." Photographs: not received. Repair invoice: not received.
