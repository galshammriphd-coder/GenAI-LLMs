# AI Challenge: Model Showdown — Ready-to-Paste Prompts

Copy each block **exactly** into a **fresh chat** in each tool (Model A and Model B). The data are already embedded — do not edit them.

---

## Task 1 — Extract  (data: DS-1)

```
Using only the table below, list FY2025 total operating income, operating expenses, impairment charges and net income, and calculate the FY2025 cost-to-income ratio. Show your calculation. If a value is not in the table, write "not provided".

| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |
(SAR millions; Northwind Gulf Bank is fictional; data are synthetic)
```

---

## Task 2 — Summarize  (data: DS-4)

```
Summarize the following ten customer complaints into: (a) the top three themes with counts, (b) the most urgent complaint and why. Use a table.

C-01 | App | "The app logs me out every time I open the transfers page." | days open: 3
C-02 | App | "My transfer of SAR 2,400 failed but the amount was debited from my account." | days open: 5
C-03 | Branch | "I was charged a fee for a statement I never requested." | days open: 2
C-04 | Phone | "The merchant confirmed a refund two weeks ago but it is not on my card." | days open: 14
C-05 | App | "The OTP arrives after it has already expired." | days open: 1
C-06 | Email | "My card annual fee was charged after I cancelled the card." | days open: 7
C-07 | Phone | "There are three transactions on my card I don't recognize, from an online store abroad." | days open: 0
C-08 | Branch | "I waited over an hour at the branch to update my ID." | days open: 4
C-09 | App | "After the latest update the app crashes on startup." | days open: 2
C-10 | Email | "The exchange rate applied to my overseas purchase included a markup I was not informed about." | days open: 6
```

---

## Task 3 — Draft in Arabic  (data: DS-1)

```
اكتب فقرة تنفيذية من 80 كلمة باللغة العربية الفصحى لمجلس الإدارة تلخص أداء البنك في عام 2025 بناءً على الجدول المرفق فقط.

| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |
(SAR millions; Northwind Gulf Bank is fictional; data are synthetic)
```

---

**Checker rule:** verify every figure in every output against DS-1 / DS-4 before the Scorer records a score. Any invented figure loses Accuracy points.
