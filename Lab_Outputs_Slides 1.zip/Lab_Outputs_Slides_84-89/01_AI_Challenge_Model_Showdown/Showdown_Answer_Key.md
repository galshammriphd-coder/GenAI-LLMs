# AI Challenge: Model Showdown — Answer Key (for the Checker and the instructor)

All data are synthetic. Use this key to verify each team's outputs; it is a reference, not the only acceptable wording.

## Task 1 — Extract (DS-1)

| Item (FY2025) | Value (SAR mn) | Source row |
|---|---|---|
| Total operating income | 6,347 | Total operating income · FY2025 |
| Operating expenses | 2,365 | Operating expenses · FY2025 (shown as (2,365)) |
| Impairment charges | 735 | Impairment charges · FY2025 (shown as (735)) |
| Net income | 2,889 | Net income · FY2025 |

**Cost-to-income ratio** = Operating expenses ÷ Total operating income = 2,365 ÷ 6,347 = **37.3%** (FY2024: 2,250 ÷ 5,910 = 38.1%).

Typical errors to penalise
- Ratio computed from one quarter only (e.g. Q1: 560 ÷ 1,515 = 37.0%) or from FY2024.
- Impairments added to expenses (2,365 + 735 = 3,100 → 48.8%): wrong definition.
- Negative signs carried into the ratio, or a figure that does not appear in the table.

## Task 2 — Summarize (DS-4)

| Theme | Count | Complaint IDs |
|---|---|---|
| Digital channels (app, OTP, failed transfer) | 4 | C-01, C-02, C-05, C-09 |
| Fees & charges | 3 | C-03, C-06, C-10 |
| Card & transaction disputes | 2 | C-04, C-07 |
| *(4th: branch service)* | *1* | *C-08* |

**Most urgent: C-07** — three unrecognised card transactions from an online store abroad: possible fraud, so there is a risk of further financial loss and the card must be blocked and disputed immediately. **Second: C-02** — SAR 2,400 debited for a failed transfer (customer funds held).

Note for the instructor: the prompt asks for the *top three* themes; a model that also lists the fourth theme (branch, 1) is still complete. A model that reports four themes as “top three”, or changes the counts, loses Accuracy points.

## Task 3 — Draft in Arabic (DS-1)

A good answer contains: net income SAR 2,889 mn (+6.4%), operating-income growth (+7.4%), improved cost-to-income (37.3% vs 38.1%) and impairments up 20.5% as a watch point — in formal Arabic, about 80 words, with no invented figures.

**Model paragraph (83 words):**

> حقق بنك نورثويند الخليجي في عام 2025 صافي دخل بلغ 2,889 مليون ريال، بنمو نسبته 6.4% مقارنة بعام 2024، مدعوماً بارتفاع إجمالي دخل العمليات بنسبة 7.4% ليصل إلى 6,347 مليون ريال. وتحسنت الكفاءة التشغيلية، إذ انخفضت نسبة التكلفة إلى الدخل إلى 37.3% مقابل 38.1% في العام السابق، رغم نمو المصروفات التشغيلية بنسبة 5.1%. في المقابل، ارتفعت مخصصات الانخفاض في القيمة بنسبة 20.5% لتبلغ 735 مليون ريال، وهو ما يستدعي متابعة دقيقة لجودة المحفظة الائتمانية خلال العام المقبل، مع الحفاظ على وتيرة النمو الحالية.

Watch for: invented comparisons (“a record year”, “highest in five years”), growth rates that do not match the table, mixed Arabic/English terms, and length far from 80 words.

## Reference growth rates (FY2025 vs FY2024)

| Line | Change |
|---|---|
| Net interest income | +7.6% |
| Fee & commission income | +7.1% |
| Total operating income | +7.4% |
| Operating expenses | +5.1% |
| Impairment charges | +20.5% |
| Net income | +6.4% |
| Cost-to-income | 37.3% vs 38.1% (−0.8 pp) |

## Debrief questions
1. Did any model invent a number? How did the Checker detect it?
2. Did the winner change by task? What does that imply for model selection?
3. How much did language quality differ between the tools?
4. Would you trust any output without checking it? Why not?
