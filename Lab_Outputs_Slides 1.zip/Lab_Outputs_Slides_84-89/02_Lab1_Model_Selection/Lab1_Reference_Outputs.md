# Lab 1 — Reference Outputs (answer key)

## T1 — reference JSON
```json
{"total_operating_income": 6347, "operating_expenses": 2365, "impairment_charges": 735, "net_income": 2889}
```
Pass if: valid JSON only (no commentary), exactly these four keys, positive numbers in SAR millions, FY2025 totals (not Q4).

## T2 — reference summary of DS-5

**Five bullets**
- FY2025 net income reached SAR 2,889 million, up 6.4% on FY2024, driven by net interest income growth.
- Efficiency improved: the cost-to-income ratio stands at 37.3%.
- Credit quality weakened: impairment charges rose 20.5% and the NPL ratio increased from 1.6% to 1.9%, mainly in SME lending and credit cards.
- Loan growth (8.3%) outpaced deposit growth (4.7%), lifting the loan-to-deposit ratio to 93.7%; capital remains strong (CET1 16.8%).
- FY2026 priorities: credit quality in growth segments, funding diversification and digital-service reliability.

**Three decisions requested from the Board**
1. Approve an independent review of the SME portfolio and underwriting standards, to be completed by the end of Q1 2026.
2. Approve a deposit-gathering programme targeting retail and SME current accounts.
3. Endorse a digital-reliability plan with quarterly reporting to the Board.

Fail signs: more or fewer than 5 bullets; decisions merged; any fact not in the memo (e.g. dividends, targets, staff numbers).

## T3 — reference classification of DS-4

| ID | Category | Urgency | Reason (≤ 10 words) |
|---|---|---|---|
| C-01 | Digital Channels | Medium | App logout blocks transfers page |
| C-02 | Digital Channels | High | SAR 2,400 debited for failed transfer |
| C-03 | Fees & Charges | Low | Fee for statement never requested |
| C-04 | Cards & Disputes | Medium | Confirmed merchant refund missing after 14 days |
| C-05 | Digital Channels | Medium | Expired OTP blocks authentication |
| C-06 | Fees & Charges | Medium | Annual fee charged after card cancellation |
| C-07 | Cards & Disputes | High | Three unrecognised foreign transactions; possible fraud |
| C-08 | Branch Service | Low | Over one hour wait to update ID |
| C-09 | Digital Channels | High | App crashes on startup after update |
| C-10 | Fees & Charges | Medium | Undisclosed exchange-rate markup on overseas purchase |

Category counts: Digital Channels 4 · Fees & Charges 3 · Cards & Disputes 2 · Branch Service 1 · Other 0.
Categories are fixed by DS-4's reference; urgency is a judgement — accept Medium/High differences if the reason is sound, but **C-07 must be High** (possible fraud) and **C-02 should be High** (customer funds debited).

## CP2 — what to look for
Low temperature (0.1): near-identical headlines that use only the given figures. High temperature (1.2): different wording each run and, sometimes, embellishment that is not in the data (e.g. "record-breaking"). Conclusion: use low temperature for financial reporting, and verify every claim.

## CP1 — measured in this kit
DS-5 English = 284 tokens, Arabic = 989 tokens (ratio ≈ 3.5×) with the offline legacy tokenizer used to prepare this kit. Recent multilingual tokenizers give a much lower ratio, so teams must measure with the tokenizer of the model they will actually use. Fit test worked in the workbook: 100 pages × 350 words = 35,000 Arabic words → ≈ 195,600 tokens with the kit tokenizer (does not fit 123,000 available tokens) vs ≈ 70,000 at 2 tokens/word (fits).

## Advanced challenge — local model (Ollama / LM Studio)
Run T1 and T3 on a small open-weight model, add it as Model 3 in the matrix, and compare accuracy, speed and Arabic quality. A local model is preferred when the data must not leave the organisation (e.g. customer complaints), when the task is narrow and repetitive (classification, extraction) and when per-call cost matters; a flagship cloud model remains preferable for nuanced writing such as board summaries.
