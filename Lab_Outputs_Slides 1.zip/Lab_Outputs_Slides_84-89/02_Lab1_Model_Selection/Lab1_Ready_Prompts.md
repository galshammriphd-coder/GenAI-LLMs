# Lab 1 — Ready-to-Run Test Prompts (data embedded)

Run every prompt in a **fresh chat**, once per model. Copy the block exactly.

## CP2 — Temperature test (Google AI Studio: 3 runs at 0.1, 3 runs at 1.2)

```
Write a one-sentence headline for a board presentation summarizing Northwind Gulf Bank's FY2025 performance using only these figures: net income SAR 2,889 mn (+6.4%), cost-to-income 37.3% (FY2024: 38.1%), impairment charges +20.5%.
```

## T1 — Figure extraction (DS-1)

```
Extract the following from the table as JSON with keys total_operating_income, operating_expenses, impairment_charges, net_income (SAR millions, FY2025 totals). Output only JSON.

| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |
(SAR millions; Northwind Gulf Bank is fictional; data are synthetic)
```

## T2 — Board-memo summary (DS-5)

```
Summarize the board memo below in exactly 5 bullet points for a busy executive, then list 3 decisions requested from the board. Do not add information not in the memo.

<memo>
To: Board of Directors, Northwind Gulf Bank (fictional) · From: Chief Executive Officer · Subject: FY2026 priorities and decisions requested

FY2025 net income reached SAR 2,889 million, 6.4% above FY2024, supported by growth in net interest income. Operating efficiency improved, with the cost-to-income ratio at 37.3%. However, impairment charges rose 20.5%, and the NPL ratio increased from 1.6% to 1.9%, with pressure concentrated in SME lending and credit cards.

Loan growth of 8.3% outpaced deposit growth of 4.7%, raising the loan-to-deposit ratio to 93.7%. Management proposes three priorities for FY2026: strengthening credit quality in growth segments, diversifying funding, and improving digital service reliability, where app-related complaints have increased.

The Board is requested to: (1) approve an independent review of the SME portfolio and underwriting standards, to be completed by the end of Q1 2026; (2) approve a deposit-gathering programme targeting retail and SME current accounts; and (3) endorse a digital reliability plan with quarterly reporting to the Board.

Management will present detailed plans for each item at the next meeting. Capital remains strong, with a CET1 ratio of 16.8%.
</memo>
```

## T3 — Complaint classification (DS-4)

```
Classify each complaint into one of: Digital Channels, Fees & Charges, Cards & Disputes, Branch Service, Other. Add urgency (High/Medium/Low). Output a table with ID, Category, Urgency, Reason (max 10 words).

C-01 | App | "The app logs me out every time I open the transfers page." | days open: 3
C-02 | App | "My transfer of SAR 2,400 failed but the amount was debited from my account." | days open: 5
C-03 | Branch | "I was charged a fee for a statement I never requested." | days open: 2
C-04 | Phone | "The merchant confirmed a refund two weeks ago but it is not on my card." | days open: 14
C-05 | App | "The OTP arrives after it has already expired." | days open: 1
C-06 | Email | "My card annual fee was charged after I cancelled the card." | days open: 7
C-07 | Phone | "There are three transactions on my card I don't recognize, from an online store abroad." | days open: 0
C-08 | Branch | "I waited over an hour at the branch to update my ID." | days open: 4
C-09 | App | "After the latest update the app crashes on startup." | days open: 2
C-10 | Email | "The exchange rate applied to my overseas purchase included a markup I was not informed about." | days open: 6
```

## CP1 — Token measurement
Paste `00_Data_Pack/DS-5_board_memo_EN.txt`, then `DS-5_board_memo_AR.txt`, into the tokenizer of the model you plan to use. Record both counts in the workbook sheet *CP1 Tokens*.
