# Multimodal interaction — ready prompts (slide 206)

**Rule: when an image contains numbers, transcribe first, then interpret.**

| Mode | Input | Prompt |
|---|---|---|
| SHOW | Screenshot of a chart | `First transcribe every value you can read from the chart into a table. Then describe the trend in two sentences and list three questions an analyst should ask.` |
| SHOW | Photo of a printed form | `Extract the fields into a table: field name, value. Mark any unreadable field as [unreadable] — do not guess.` |
| TALK | Voice mode | `I will rehearse a 2-minute board presentation. After I finish, give feedback on clarity, pace, and any figure I stated without context.` |
| COMBINE | Chart image + the source table | `Does the chart represent the table correctly? Check axis start, scale, labels and every value; list each discrepancy.` |

## Video prompt anatomy
subject · action · setting · camera movement · style · duration

Example: *“A stylised hand tapping a report button on a generic mail app, check-mark animation, static camera, flat illustration in navy and teal, 8 seconds.”*

Avoid real people, brands and any depiction of real financial data.
