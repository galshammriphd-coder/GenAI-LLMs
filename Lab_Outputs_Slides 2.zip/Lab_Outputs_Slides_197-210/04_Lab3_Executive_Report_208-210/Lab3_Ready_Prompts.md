# Lab 3 — Ready-to-Paste Prompt Chain (data embedded)

Run in order, in one chat per team. The **Verifier** recomputes the figures in `Lab3_Analysis_Workbook.xlsx` before anything goes into the report. All data are synthetic.

---

## Step 2a · FA-01 Variance analysis (DS-1) — CP1
```
<role>You are a senior financial analyst at a commercial bank.</role>
<context>Audience: Executive Committee. Data: FY2024 and FY2025 income statement in SAR millions.</context>
<task>Analyze year-on-year changes for each line item.</task>
<steps>1. For each line, compute change in SAR m and %. Show the formula once. 2. Identify the 3 largest positive and negative contributors to the change in net income. 3. Write 3 bullets of insight.</steps>
<constraints>Use only the data. Round % to one decimal. If a value is missing, write "not provided".</constraints>
<format>Table: Line item | FY2024 | FY2025 | Δ SAR m | Δ % ; then "Key contributors" and "Insights".</format>
<data>
| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |
(SAR millions; Northwind Gulf Bank is fictional; data are synthetic)
</data>
```

## Step 2b · FA-02 Ratio analysis (DS-1 + DS-2)
```
Using only <data>, calculate for FY2024 and FY2025: cost-to-income, loan-to-deposit, NPL ratio, NPL coverage, ROE and ROA. Show each formula and value. Express changes in ratios in percentage points (pp), never in %. If an input is missing, write "not provided".
<data>
| Line item | Q1 2025 | Q2 2025 | Q3 2025 | Q4 2025 | FY2025 | FY2024 |
|---|---|---|---|---|---|---|
| Net interest income | 1,120 | 1,165 | 1,190 | 1,240 | 4,715 | 4,380 |
| Fee & commission income | 310 | 325 | 298 | 342 | 1,275 | 1,190 |
| Other operating income | 85 | 70 | 92 | 110 | 357 | 340 |
| Total operating income | 1,515 | 1,560 | 1,580 | 1,692 | 6,347 | 5,910 |
| Operating expenses | (560) | (575) | (590) | (640) | (2,365) | (2,250) |
| Impairment charges | (140) | (150) | (210) | (235) | (735) | (610) |
| Profit before zakat | 815 | 835 | 780 | 817 | 3,247 | 3,050 |
| Zakat | (90) | (92) | (86) | (90) | (358) | (336) |
| Net income | 725 | 743 | 694 | 727 | 2,889 | 2,714 |
(SAR millions; Northwind Gulf Bank is fictional; data are synthetic)

| Item | 31 Dec 2024 | 31 Dec 2025 | Change |
|---|---|---|---|
| Total assets (SAR bn) | 248.0 | 266.5 | +7.5% |
| Net loans (SAR bn) | 165.2 | 178.9 | +8.3% |
| Customer deposits (SAR bn) | 182.4 | 191.0 | +4.7% |
| Total equity (SAR bn) | 21.4 | 23.1 | +7.9% |
| Loan-to-deposit ratio | 90.6% | 93.7% | +3.1 pp |
| NPL ratio | 1.6% | 1.9% | +0.3 pp |
| NPL coverage ratio | 168% | 152% | −16 pp |
| CET1 ratio | 17.2% | 16.8% | −0.4 pp |
| ROE | 13.1% | 13.0% | −0.1 pp |
| ROA | — | 1.12% | — |
(ROE FY2025 = 2,889 ÷ average equity 22,250 SAR m; ROA = 2,889 ÷ average assets 257,250 SAR m)
</data>
```

## Step 2c · Portfolio prompt (DS-3)
```
Using only <portfolio>, compute for each segment: FY2025 loans, growth vs FY2024 (%), NPL ratio, NPL amount (loans × NPL ratio), share of total loans and share of total NPLs. Show the formulas once. Output a table, then three [Observed] statements.
<portfolio>
| Segment | Loans 31 Dec 2024 (SAR bn) | Loans 31 Dec 2025 (SAR bn) | Growth | NPL ratio 2025 |
|---|---|---|---|---|
| Retail mortgages | 48.1 | 52.4 | +8.9% | 0.9% |
| Personal finance | 37.0 | 38.6 | +4.3% | 1.7% |
| Credit cards | 5.9 | 6.2 | +5.1% | 4.1% |
| SME | 18.2 | 21.3 | +17.0% | 3.8% |
| Corporate | 56.0 | 60.4 | +7.9% | 2.0% |
| Total | 165.2 | 178.9 | +8.3% | 1.9% |
</portfolio>
```

## Step 3 · Findings — CP2
```
Using only <analysis> (the verified outputs above) and <complaints>, write 5–7 findings for the Board. Tag each one [Observed] (stated in or calculated from the data) or [Hypothesis] (a possible explanation that needs more data). Each finding must include one figure and its source table (DS-1, DS-2, DS-3 or DS-4). Include one customer-experience finding from the complaint themes. Do not introduce external causes.
<analysis>[paste verified FA-01, FA-02 and portfolio outputs]</analysis>
<complaints>
C-01 | App | "The app logs me out every time I open the transfers page." | days open: 3
C-02 | App | "My transfer of SAR 2,400 failed but the amount was debited from my account." | days open: 5
C-03 | Branch | "I was charged a fee for a statement I never requested." | days open: 2
C-04 | Phone | "The merchant confirmed a refund two weeks ago but it is not on my card." | days open: 14
C-05 | App | "The OTP arrives after it has already expired." | days open: 1
C-06 | Email | "My card annual fee was charged after I cancelled the card." | days open: 7
C-07 | Phone | "There are three transactions on my card I don't recognize, from an online store abroad." | days open: 0
C-08 | Branch | "I waited over an hour at the branch to update my ID." | days open: 4
C-09 | App | "After the latest update the app crashes on startup." | days open: 2
C-10 | Email | "The exchange rate applied to my overseas purchase included a markup I was not informed about." | days open: 6
</complaints>
```

## Step 4 · Recommendations
```
Using only <findings>, propose 3 recommendations. For each: action, owner (role), timing (quarter), expected effect, and the finding it addresses. Output a table.
<findings>[paste tagged findings]</findings>
```

## Step 5 · Executive summary (SCQA) — CP3
```
You are the Head of Financial Planning & Analysis writing for the Executive Committee of Northwind Gulf Bank (fictional).
Using only <analysis> (verified figures), write an executive summary of ≤ 150 words using SCQA.
Structure: Headline (≤ 15 words) · Situation · Complication · Question · Answer (with 2 recommendations and owners).
Style: neutral, factual, no adjectives without figures; ratios explained on first use. Use pp for ratio changes.
End with "Decision requested:" in one sentence. Count the words before finalising.
<analysis>[paste verified analysis + recommendations]</analysis>
```

## Step 6a · Chart recommendation — CP4
```
Recommend the single best chart for this board message: "Credit cards and SME carry the highest NPL ratios". Give chart type, series, axis settings and an action title. Rules: 2D only, value axis starting at zero, values labelled, no 3D or decorative effects.
```
Then build the chart in Excel/Sheets from DS-3 (see the *Portfolio (DS-3)* sheet). **Never use an image generator for a chart.**

## Step 6b · Six-slide storyline — CP4
```
Create a six-slide storyline for the Board using the data-story arc (context, tension, insight, resolution, call to action). For each slide: an action title (≤ 14 words), a key visual, three supporting points with figures and speaker notes (≤ 80 words). Use only <findings> and <recommendations>.
Good title: "SME holds 12% of loans but 24% of bad loans". Bad title: "Loan portfolio".
<findings>[...]</findings>
<recommendations>[...]</recommendations>
```

## Step 7 · Final check
```
Review the report below. List every figure with its source; flag any figure that does not match the data, any ratio change not in pp, any untagged cause, and any promotional adjective. Do not rewrite the report.
```
