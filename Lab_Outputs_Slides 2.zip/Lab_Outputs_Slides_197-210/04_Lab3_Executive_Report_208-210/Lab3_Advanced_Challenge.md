# Lab 3 — Advanced Challenge (reference outputs)

## (a) Report cover image — text-to-image prompt
```
Abstract editorial illustration for a bank's annual board report cover: layered translucent geometric shapes suggesting growth and caution, soft light background, navy (#233C97) and teal (#0F9488) palette with a single violet accent, generous empty space at the top for a title added later. No text, no letters, no numbers, no logos, no people, no charts.
```
Check before use: no embedded text or logos; nothing that looks like real data.

## (b) 60-second audio brief — script for a free TTS tool (≈ 150 words)
> Good morning. Here is the FY2025 brief for Northwind Gulf Bank.
> Profit grew six point four percent, to two thousand eight hundred and eighty-nine million riyals, and efficiency improved: the cost-to-income ratio fell to thirty-seven point three percent.
> The concern is credit. Impairment charges rose twenty point five percent, and the non-performing loan ratio rose from one point six to one point nine percent. The small and medium enterprise book grew seventeen percent and now holds about a quarter of all bad loans, with only an eighth of all lending.
> Funding is tighter too: loans grew faster than deposits, lifting the loan-to-deposit ratio to ninety-three point seven percent.
> We propose three actions: an SME review led by the Chief Risk Officer in the first quarter, a cards collections review by the Head of Retail, and a deposit plan from the Treasurer in the second quarter.
> We ask the Board to approve them today.

Tip: write numbers in words for TTS and listen once to check every figure.

## (c) The sceptical board member — five hardest questions (and answers from the data)
| # | Question | Answer grounded in the data |
|---|---|---|
| 1 | Profit grew 6.4%, so why should we worry? | Impairments grew 20.5% — three times faster than profit — and the NPL ratio rose 0.3 pp to 1.9% (DS-1, DS-2). |
| 2 | Is SME really the problem, or just growing fast? | Both: SME holds ≈ 12% of loans but ≈ 24% of NPLs, twice its share (DS-3). Whether underwriting loosened is a hypothesis we will test with vintage data. |
| 3 | Corporate has the largest bad-loan amount. Why not focus there? | Corporate NPLs (≈ SAR 1.21 bn) are in line with its loan share (≈ 34%) and its ratio (2.0%) is near average; the disproportion is in SME and cards (DS-3). |
| 4 | Can we fund growth at a 93.7% loan-to-deposit ratio? | Loans grew 8.3% vs deposits 4.7% (DS-2); the Treasurer's deposit plan targets that gap. Liquidity limits and targets are not in our data — we will bring them. |
| 5 | Coverage fell from 168% to 152%. Are we under-provisioned? | Coverage remains above 100% but fell 16 pp (DS-2). Adequacy needs a risk-model view that is not in this pack — we will report back in Q1. |

Prompt used:
```
Act as a sceptical independent board member with banking experience. Read the report below and ask the five hardest questions you would raise in the meeting. Do not answer them.
```
